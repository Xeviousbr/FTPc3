﻿using System;
using System.Collections.Generic;
using System.Net;
using System.Net.Http;
using System.Threading.Tasks;
using System.Web.Script.Serialization;
using System.Xml;
using FEPAM.DAL;


namespace WS_PROCERGS
{
    public class ExecutaWs
    {

        private static string sproxy = "";
        private static string porta = "";
        private static string httpUserName = "";
        private static string httpPassword = "";
        private static string usuario = "";
        private static string senha = "";

        //Com XML
        public static async Task Executa(Boolean Agora)
        {
            try
            {
                string DataHoje = "";
                string URLWebServiceProcergs = "";

#if DEBUG
                // Para executar novamente algma data desta API o ideal é setar a data fixa e mandar executar o serviço no servidor
                DataHoje = "2021-10-11";

                URLWebServiceProcergs = "https://sechml.procergs.com.br/sra/public/rest/solicitacao/listaPorDataProcesso/";

                httpUserName = "alexandrebg";
                httpPassword = "rewq@4321";

                usuario = "sisu";
                senha = "mapef10";

                sproxy = "proxy";
                porta = "3128";

#else
                DataHoje = DateTime.Now.ToString("yyyy-MM-dd");
                //DataHoje = "2021-09-30";

                URLWebServiceProcergs = Config.GetSingleNode("configuracoes/URLWebServiceProcergs").InnerText.ToString();

                httpUserName = Config.GetSingleNode("configuracoes/httpUserName").InnerText.ToString();
                httpPassword = Config.GetSingleNode("configuracoes/httpPassword").InnerText.ToString();

                usuario = Config.GetSingleNode("configuracoes/usuarioNome").InnerText.ToString();
                senha = Config.GetSingleNode("configuracoes/usuarioSenha").InnerText.ToString();

                sproxy = Config.GetSingleNode("configuracoes/proxy").InnerText.ToString();
                porta = Config.GetSingleNode("configuracoes/porta").InnerText.ToString();

#endif

                Config config = new Config();
                config.GetInitialConfig();

                //Verifica qual serviço está na hora de executar
                config.GetServiceToExecute();

#if DEBUG
                bool ExecutarAgora = true;
#else
                bool ExecutarAgora = false;
                if (Agora)
                    ExecutarAgora = true;
                else
                    ExecutarAgora = (!String.IsNullOrEmpty(config.Servico));                
#endif                

                if (ExecutarAgora)
                {
                    string proxyUri = string.Format("{0}:{1}", sproxy, porta);

                    NetworkCredential proxyCreds = new NetworkCredential(httpUserName, httpPassword);

                    WebProxy proxy = new WebProxy(proxyUri, false)
                    {
                        UseDefaultCredentials = false,
                        Credentials = proxyCreds,
                    };

                    // Now create a client handler which uses that proxy

                    HttpClient client = null;
                    HttpClientHandler httpClientHandler = new HttpClientHandler()
                    {
                        Proxy = proxy,
                        PreAuthenticate = true,
                        UseDefaultCredentials = false,
                    };

                    // You only need this part if the server wants a username and password:
                    httpClientHandler.Credentials = new NetworkCredential(usuario, senha);

                    client = new HttpClient(httpClientHandler);

#if DEBUG
                    string jsonData = "[{'nroSolicitacao':88281,'nroCodAtividade':1030.2,'nroCodIbge':4318051,'nroCodTipoSolicitacao':281,'nroCodTipoAssunto':6611,'vlrTaxa':418.25,'dtVencimento':'2021-11-04','dtPagamento':'2021-10-20','nroNumeroGA':5000871844,'participantes':[{'txtTipoPapel':'Representante Legal','txtTipoPessoa':'PF','txtDocumentoIdentificacao':'805.142.350-04','txtNome':'Marcelo Z Correa','txtCep':'95334000','txtTipoLogradouro':'Rua','txtLogradouro':'Rua das Ericas 378','txtNumero':null,'txtComplemento':null,'nroCodIbgeMunicipio':4323309,'txtNomeMunicipio':'Vila Flores','txtSiglaUfMunicipio':'RS','txtEmail':'licenceconsultoriaambiental@gmail.com','txtFone':'(54) 99655-3061','txtReferencia':null,'txtBairro':'Vila Nova','txtNomeContato':null,'txtVinculoContato':null,'txtEmailContato':null,'txtFoneContato':null,'txtNroArt':null,'txtInclusao':null,'txtTipoPessoaRepresentada':null,'txtDocIdentPessoaRepresentada':null},{'txtTipoPapel':'Empreendedor Principal','txtTipoPessoa':'PJ','txtDocumentoIdentificacao':'33.283.460/0001-23','txtNome':'Taciane Montagna Me','txtCep':'99270000','txtTipoLogradouro':'Linha','txtLogradouro':'Quarta','txtNumero':null,'txtComplemento':null,'nroCodIbgeMunicipio':4318051,'txtNomeMunicipio':'São Domingos do Sul','txtSiglaUfMunicipio':'RS','txtEmail':'basaltopellizzaro@gmail.com','txtFone':'(54) 99710-0445','txtReferencia':null,'txtBairro':'Distrito Santa Gema','txtNomeContato':null,'txtVinculoContato':null,'txtEmailContato':null,'txtFoneContato':null,'txtNroArt':null,'txtInclusao':null,'txtTipoPessoaRepresentada':null,'txtDocIdentPessoaRepresentada':null},{'txtTipoPapel':'Responsável Técnico','txtTipoPessoa':'PF','txtDocumentoIdentificacao':'688.853.850-87','txtNome':'Telmo Boeri','txtCep':'95900474','txtTipoLogradouro':'Rua','txtLogradouro':'Duque de Caxias 209','txtNumero':null,'txtComplemento':null,'nroCodIbgeMunicipio':4311403,'txtNomeMunicipio':'Lajeado','txtSiglaUfMunicipio':'RS','txtEmail':'telmo@geoambiental.com.br','txtFone':'(51) 3710-5400','txtReferencia':null,'txtBairro':'Americano','txtNomeContato':null,'txtVinculoContato':null,'txtEmailContato':null,'txtFoneContato':null,'txtNroArt':'555','txtInclusao':null,'txtTipoPessoaRepresentada':null,'txtDocIdentPessoaRepresentada':null}],'empreendimento':{'nroCodEmpreendimento':421436,'vlrPorteEmpreendimento':4.5E7,'txtCepEmpreendimento':'99270000','txtTipoLogradouroEmpreendimento':'Floresta','txtLogradouroEmpreendimento':'Linha','txtNumeroEmpreendimento':'123','txtComplementoEmpreendimento':null,'txtReferenciaEmpreendimento':null,'txtBairroEmpreendimento':null,'txtMunicipioEmpreendimento':'São Domingos do Sul','nroLatitudeEmpreendimento':-28.544109,'nroLongitudeEmpreendimento':-51.879802,'txtCodCar':null},'txtCodProcesso':'0000230567215','dthGeracaoProcesso':'2021-10-20T16:22:26','txtCpfSolicitante':'40930866053','txtNomeSolicitante':'Lenira Nascimento','indMaisDeUmMunicipio':false,'indUcEstadual':false,'dthPrimeiroEnvioCA':'2021-10-20T16:21:45','indSupressaoVegetacaoNativa':null,'vlrQuitacao':null,'indEmpreendimentoAreaRisco':false,'txtCodProcessoAnterior':null,'indTemMC':false,'qtdMunicipiosAdicionais':0,'codMunicipiosAdicionais':null,'indDetalhamento':true}]";
#else
                    Task<string> getStringTask = client.GetStringAsync(URLWebServiceProcergs + DataHoje);
                    string jsonData = await getStringTask;
#endif

                    JavaScriptSerializer ser = new JavaScriptSerializer();
                    var listProcesso = ser.Deserialize<List<Processo>>(jsonData);

                    Logs.WriteLog("Numero de intens neste JSON " + listProcesso.Count.ToString());

                    ExecutaWs.InsertProcessos(listProcesso);

                    Logs.WriteLog("Serviço executado com sucesso! \n JSON:" + jsonData);
                }

            }
            catch (Exception ex)
            {
                Logs.WriteLog("ERRO no serviço \n MENSAGEM DE ERRO:" + ex.ToString());
                if (ex.InnerException != null)
                {
                    Logs.WriteLog("ERRO no serviço \n MENSAGEM DE ERRO:" + ex.InnerException.Message);
                }
            }
        }

        public static void InsertProcessos(List<Processo> listProcesso)
        {
            try
            {
                foreach (Processo processo in listProcesso)
                {
                    if (!processo.verificaSeExisteSolicitacao())
                    {
                        processo.Insert();
                        foreach (Participante participante in processo.Participantes)
                        {
                            participante.nroSolicitacao = processo.nroSolicitacao;
                            participante.Insert();
                        }
                        processo.Empreendimento.indMaisDeUmMunicipio = processo.indMaisDeUmMunicipio.HasValue && processo.indMaisDeUmMunicipio.Value ? processo.indMaisDeUmMunicipio.Value : false;
                        processo.Empreendimento.nroSolicitacao = processo.nroSolicitacao;
                        processo.Empreendimento.Insert();

                        if (processo.codMunicipiosAdicionais != null)
                        {
                            Logs.WriteLog("codMunicipiosAdicionais da solicitação " + processo.nroSolicitacao.ToString() + " = " + processo.codMunicipiosAdicionais.Count.ToString());
                            for (int i = 0; i < processo.codMunicipiosAdicionais.Count; i++)
                                processo.codMunicipiosAdicionaInsert(processo.nroSolicitacao, processo.Empreendimento.nroCodEmpreendimento, processo.codMunicipiosAdicionais[i]);
                        }
                        else
                            Logs.WriteLog("codMunicipiosAdicionais da solicitação " + processo.nroSolicitacao.ToString() + " é vazio");
                        if (processo.indDetalhamento == true)
                            ExecutaLAC.Executa(processo.nroSolicitacao, sproxy, porta, httpUserName, httpPassword, usuario, senha);
                    }
                }
            }
            catch (Exception ex)
            {
                Logs.WriteLog("ERRO no serviço \n MENSAGEM DE ERRO:" + ex.InnerException.Message);
            }
        }

    }

}
