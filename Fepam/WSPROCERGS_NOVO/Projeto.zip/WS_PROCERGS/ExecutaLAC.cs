﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using FEPAM.DAL;
using System.Net;
using System.Net.Http;
using System.Web.Script.Serialization;

namespace WS_PROCERGS
{
    public class ExecutaLAC
    {
        
        string senha = "";

        //Com XML
        public static async Task Executa(Int64 Solicitacoes, string sproxy, string porta, string httpUserName, string httpPassword, string usuario, string senha)
        {
            string URLWebServiceProcergs = "";
            try
            {
                string proxyUri = string.Format("{0}:{1}", sproxy, porta);
                NetworkCredential proxyCreds = new NetworkCredential(httpUserName, httpPassword);
                WebProxy proxy = new WebProxy(proxyUri, false)
                {
                    UseDefaultCredentials = false,
                    Credentials = proxyCreds,
                };

                // Now create a client handler which uses that proxy

                HttpClient client = null;
                HttpClientHandler httpClientHandler = new HttpClientHandler()
                {
                    Proxy = proxy,
                    PreAuthenticate = true,
                    UseDefaultCredentials = false,
                };

                // You only need this part if the server wants a username and password:
                httpClientHandler.Credentials = new NetworkCredential(usuario, senha);

                client = new HttpClient(httpClientHandler);

#if DEBUG
                string jsonData = "[{'SOLICITACAO':88293,'WS_ORA_nro_funcionarios':853,'WS_ORA_combustivel':[{'tabela':'Combustíveis','id':37,'descricao':'BIODIESEL','WS_ORA_consumo_dia_comb':121.36,'WS_ORA_unid_medida':{'tabela':'Unidades de Medida','id':55,'descricao':'m³ dia'}},{'tabela':'Combustíveis','id':75,'descricao':'ÓLEO DIESEL','WS_ORA_consumo_dia_comb':52.64,'WS_ORA_unid_medida':{'tabela':'Unidades de Medida','id':57,'descricao':'L'}}],'WS_ORA_tancagem':[{'WS_ORA_nome_tanque':'Tanque nro 1','WS_ORA_substancia':'XXXXXXXXXXXXXXXXXXXXXXXXXXXXX','WS_ORA_vol_tanque':168.52,'WS_ORA_unid_medida':{'tabela':'Unidades de Medida','id':57,'descricao':'L'},'WS_ORA_estado_materia':'Líquido','WS_ORA_contencao':false,'WS_ORA_local_tancagem':'Depósito Coberto'},{'WS_ORA_nome_tanque':'Tanque 2','WS_ORA_substancia':'mmmmmmmmmmmmmmmmmmm','WS_ORA_vol_tanque':635.25,'WS_ORA_unid_medida':{'tabela':'Unidades de Medida','id':54,'descricao':'m³'},'WS_ORA_estado_materia':'Gás','WS_ORA_contencao':true,'WS_ORA_local_tancagem':'Subterrâneo'}],'WS_ORA_cap_prod':[{'tabela':'Materiais','id':2940,'descricao':'telhas e ou tijolos','WS_ORA_qtd_max_mes':1240,'WS_ORA_unid_medida':{'tabela':'Unidades de Medida','id':50,'descricao':'un'}},{'tabela':'Materiais','id':8777,'descricao':'resina p telha tijolos','WS_ORA_qtd_max_mes':24,'WS_ORA_unid_medida':{'tabela':'Unidades de Medida','id':404,'descricao':'caixas'}}],'WS_ORA_equipamento':[{'tabela':'Equipamentos','id':5746,'descricao':'cortador de tijolos','WS_ORA_qtd_equipamento':5,'WS_ORA_cap_nominal':4},{'tabela':'Equipamentos','id':9049,'descricao':'máquina de fabricar tijolos','WS_ORA_qtd_equipamento':3,'WS_ORA_cap_nominal':2}],'WS_ORA_processo_etapa':[{'ordemItem':0,'txtItem':'Processo primeiro','itensSublista':[{'ordemSubItem':0,'txtSubItem':'Etapa inicial'},{'ordemSubItem':1,'txtSubItem':'Etapa final'}]},{'ordemItem':1,'txtItem':'Processo segundo','itensSublista':[{'ordemSubItem':0,'txtSubItem':'Etapa única'}]}],'WS_ORA_area_terreno':1254.63,'WS_ORA_area_construida':958.85}]";
#else
                // string URLWebServiceProcergs = "";
                // https://sectre.procergs.com.br/sra/public/rest/solicitacao/detalhamentoPorSolicitacao/88293
                Task<string> getStringTask = client.GetStringAsync(URLWebServiceProcergs);
                string jsonData = await getStringTask;
#endif
                JavaScriptSerializer ser = new JavaScriptSerializer();
                var vWSORA = ser.Deserialize<List<WSORA>>(jsonData);
                vWSORA[0].Insert();

                int x = 0;

            }
            catch (Exception ex)
            {
                Logs.WriteLog("ERRO no serviço \n MENSAGEM DE ERRO:" + ex.ToString());
                if (ex.InnerException != null)
                {
                    Logs.WriteLog("ERRO no serviço \n MENSAGEM DE ERRO:" + ex.InnerException.Message);
                }
            }
        }
    }

}
